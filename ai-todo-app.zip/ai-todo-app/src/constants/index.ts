import { Category } from '../types';

export const COLORS = {
  // Primary palette
  primary: '#6C63FF',
  primaryLight: '#8B85FF',
  primaryDark: '#4A42D4',

  // Accent
  accent: '#FF6584',
  accentGreen: '#43D9AD',
  accentOrange: '#FF9F43',
  accentYellow: '#FFDD59',

  // Dark theme
  dark: {
    bg: '#0A0A0F',
    surface: '#13131A',
    card: '#1C1C28',
    border: '#2A2A3A',
    text: '#FFFFFF',
    textSecondary: '#8888AA',
    textMuted: '#55556A',
  },

  // Light theme
  light: {
    bg: '#F5F5FF',
    surface: '#FFFFFF',
    card: '#FAFAFE',
    border: '#E8E8F0',
    text: '#0A0A1F',
    textSecondary: '#5555AA',
    textMuted: '#9999BB',
  },

  // Priority colors
  priority: {
    low: '#43D9AD',
    medium: '#FFDD59',
    high: '#FF9F43',
    urgent: '#FF6584',
  },

  // Category colors
  categories: [
    '#6C63FF', '#FF6584', '#43D9AD', '#FF9F43',
    '#FFDD59', '#4FC3F7', '#CE93D8', '#80DEEA',
    '#A5D6A7', '#FFCC80', '#EF9A9A', '#90CAF9',
  ],
};

export const CATEGORY_ICONS = [
  'briefcase', 'home', 'heart', 'book', 'shopping-cart',
  'dumbbell', 'code', 'music', 'camera', 'plane',
  'star', 'flag', 'zap', 'coffee', 'globe',
];

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'work', name: 'Work', color: '#6C63FF', icon: 'briefcase' },
  { id: 'personal', name: 'Personal', color: '#43D9AD', icon: 'heart' },
  { id: 'health', name: 'Health', color: '#FF6584', icon: 'activity' },
  { id: 'shopping', name: 'Shopping', color: '#FF9F43', icon: 'shopping-cart' },
  { id: 'learning', name: 'Learning', color: '#FFDD59', icon: 'book' },
  { id: 'home', name: 'Home', color: '#4FC3F7', icon: 'home' },
];

export const PRIORITY_LABELS = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  urgent: 'Urgent',
};

export const REPEAT_LABELS = {
  none: 'No Repeat',
  daily: 'Daily',
  weekly: 'Weekly',
  monthly: 'Monthly',
};

export const AI_SYSTEM_PROMPT = `You are an intelligent productivity assistant built into an AI To-Do app. You help users:

1. **Create & Organize Tasks**: Parse natural language to extract task details (title, due date, priority, category, reminders). Return structured JSON when asked to create tasks.
2. **Smart Categorization**: Suggest the best category for tasks based on content.
3. **Priority Recommendations**: Assess urgency and importance to recommend priority levels.
4. **Reminder Suggestions**: Recommend smart reminder times based on task type and due dates.
5. **Productivity Insights**: Analyze task patterns and provide actionable advice.
6. **Break Down Tasks**: Help users split complex tasks into subtasks.
7. **Daily Planning**: Help users plan their day based on pending tasks.

When creating tasks from natural language, respond with JSON in this format:
{
  "action": "create_task",
  "task": {
    "title": "...",
    "description": "...",
    "categoryId": "work|personal|health|shopping|learning|home",
    "priority": "low|medium|high|urgent",
    "dueDate": "YYYY-MM-DD or null",
    "dueTime": "HH:MM or null",
    "repeatInterval": "none|daily|weekly|monthly",
    "subtasks": [{"title": "..."}],
    "tags": ["..."],
    "aiNotes": "Brief explanation of your choices"
  }
}

For general conversation, respond naturally and helpfully. Be concise but thorough. Use emojis sparingly for friendliness.`;
